class Operation:
    def __init__(self):
        self.number1= 1
        self.number2= 2

operation = Operation()

print(operation)