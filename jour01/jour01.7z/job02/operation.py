class Operation:
    def __init__(self):
        self.number1= 12
        self.number2= 3

    def show_number1(self):
        print("le Nombre 1 est : " + str(self.number1))
    
    def show_number2(self):
        print("le Nombre 1 est : " + str(self.number2))




operation = Operation()

#print(operation)
operation.show_number1()
operation.show_number2()